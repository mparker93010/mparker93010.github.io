
let result = "2" + 3;
alert(result);